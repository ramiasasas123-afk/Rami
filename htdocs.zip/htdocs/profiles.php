<?php
require('routeros_api.class.php');
$API=new RouterosAPI();
$result=[];
if($API->connect('213.6.209.159:8788','rami','amiami199')){
    $profiles=$API->comm('/ip/hotspot/user/profile/print');
    foreach($profiles as $p){
        $result[]=$p['name'];
    }
    $API->disconnect();
}
header('Content-Type: application/json');
echo json_encode($result);
?>