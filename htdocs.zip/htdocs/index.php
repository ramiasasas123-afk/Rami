<!DOCTYPE html>
<html lang="ar">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>توليد كروت MikroTik</title>
<style>
body { font-family: Arial,sans-serif; text-align:center; background:#f4f4f9; margin:0; padding:0; color:#333; }
h1 { background:#4caf50; color:white; padding:20px; margin:0; }
form { background:white; margin:30px auto; padding:20px; border-radius:10px; width:90%; max-width:600px; }
label { display:block; text-align:left; margin-bottom:8px; font-weight:bold; }
input, select, button { width:100%; padding:10px; margin-bottom:20px; border:1px solid #ccc; border-radius:5px; font-size:16px; }
button { background:linear-gradient(to right,#4caf50,#45a049); color:white; border:none; cursor:pointer; }
button:hover { background:linear-gradient(to right,#45a049,#4caf50); }
#progress { margin-top:20px; font-size:18px; color:#4caf50; }
</style>
</head>
<body>
<h1>🎫 توليد كروت الإنترنت - MikroTik</h1>

<form action="generate.php" method="POST">
    <label>عدد الصفوف لكل صفحة:</label>
    <input type="number" name="rows_per_page" value="28" required>
    <label>عدد الأعمدة لكل صفحة:</label>
    <input type="number" name="columns_per_page" value="5" required>
    <label>عدد الصفحات:</label>
    <input type="number" name="total_pages" value="10" required>
    <label>حجم الخط:</label>
    <input type="number" name="font_size" value="14" required>
    <label>عدد الأرقام في الكرت:</label>
    <input type="number" name="card_numbers" value="9" required>
    <label>أول رقم في الكرت:</label>
    <input type="number" name="first_digit" value="1" required>
    <label>عرض البطاقة (mm):</label>
    <input type="number" name="card_width" value="36" required>
    <label>طول البطاقة (mm):</label>
    <input type="number" name="card_height" value="6" required>
    <label>المسافة الأفقية بين الكروت (mm):</label>
    <input type="number" name="horizontal_spacing" value="4" required>
    <label>المسافة الرأسية بين الكروت (mm):</label>
    <input type="number" name="vertical_spacing" value="4" required>
    <label>البروفايل المستخدم:</label>
    <select name="profile" id="profile" required></select>
    <label>مدة الصلاحية بالساعات:</label>
    <input type="number" name="validity_hours" value="10" required>
    <label>تحديد استهلاك الميجابايت:</label>
    <input type="number" name="data_limit" value="4000" required>
    <label>المسافة الأفقية لموقع رقم الصفحة (mm):</label>
    <input type="number" name="page_number_x" value="10" required>
    <label>المسافة الرأسية لموقع رقم الصفحة (mm):</label>
    <input type="number" name="page_number_y" value="-11" required>
    <button type="submit">توليد الكروت</button>
</form>

<div id="progress">التقدم سيظهر هنا...</div>

<script>
fetch("profiles.php")
.then(res=>res.json())
.then(data=>{
    let select=document.getElementById("profile");
    data.forEach(p=>{
        let opt=document.createElement("option");
        opt.value=p;
        opt.text=p;
        select.appendChild(opt);
    });
});

// تحديث التقدم كل ثانية
setInterval(()=>{
    fetch("progress.php")
    .then(res=>res.text())
    .then(text=>{
        document.getElementById("progress").innerText=text;
    });
},1000);
</script>
</body>
</html>
