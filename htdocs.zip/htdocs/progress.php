<?php
$progressFile=__DIR__.'/progress.txt';
if(file_exists($progressFile)){
    echo file_get_contents($progressFile);
} else {
    echo "لم يبدأ أي عمل بعد...";
}
?>