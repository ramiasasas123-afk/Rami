<?php
require('routeros_api.class.php');
require('fpdf/fpdf.php');

set_time_limit(0);
ignore_user_abort(true);

// =========================
// استلام المدخلات
// =========================
$rows=intval($_POST['rows_per_page']);
$cols=intval($_POST['columns_per_page']);
$pages=intval($_POST['total_pages']);
$digits=intval($_POST['card_numbers']);
$first=intval($_POST['first_digit']);
$profile=$_POST['profile'];
$hours=intval($_POST['validity_hours']);
$data=intval($_POST['data_limit']);
$pageNumberX=floatval($_POST['page_number_x']);
$pageNumberY=floatval($_POST['page_number_y']);
$horizontalSpacing=intval($_POST['horizontal_spacing']);
$verticalSpacing=intval($_POST['vertical_spacing']);
$cardWidth=floatval($_POST['card_width']);
$cardHeight=floatval($_POST['card_height']);
$fontSize=intval($_POST['font_size']);

$cardsPerPage=$rows*$cols;
$totalCards=$cardsPerPage*$pages;

// إنشاء مجلد
if(!is_dir("data")) mkdir("data");

// =========================
// تحميل المستخدمين لآخر شهرين
// =========================
$recentFile = "data/recent_users.txt";
$recentUsers = [];

if(file_exists($recentFile)){
    $lines = file($recentFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

    $now = time();
    $twoMonths = 60 * 60 * 24 * 60; // 60 يوم تقريبًا

    foreach($lines as $line){
        if(strpos($line, '|') !== false){
            list($user, $timestamp) = explode('|', $line);

            if(($now - $timestamp) < $twoMonths){
                $recentUsers[$user] = $timestamp;
            }
        }
    }
}

// =========================
// توليد المستخدمين
// =========================
$users=[];
$generated=[];

for($i=0;$i<$totalCards;$i++){
    do{
        $rand=str_pad(rand(0,pow(10,$digits-1)-1),$digits-1,'0',STR_PAD_LEFT);
        $user=$first.$rand;

    }while(isset($generated[$user]) || isset($recentUsers[$user]));

    $generated[$user]=true;
    $users[]=$user;
}

// =========================
// ملف التقدم
// =========================
$progressFile=__DIR__.'/progress.txt';
file_put_contents($progressFile,"بدء توليد الكروت...");

// =========================
// إنشاء PDF
// =========================
$pdf=new FPDF();
$pdf->SetMargins(10,10,10);
$pdf->SetAutoPageBreak(false);

$counter=0;
foreach($users as $user){
    if($counter % $cardsPerPage === 0){
        $pdf->AddPage();
        $pageNumber=floor($counter/$cardsPerPage)+1;
        $pdf->SetFont('Arial','',10);
        $pdf->SetXY($pageNumberX,$pageNumberY);
        $pdf->Cell(0,10,"R: $pageNumber",0,0,'C');
    }

    $position=$counter % $cardsPerPage;
    $row=floor($position/$cols);
    $col=$position % $cols;
    $x=10+($col*($horizontalSpacing+$cardWidth));
    $y=10+($row*($verticalSpacing+$cardHeight));

    $pdf->SetFont('Arial','B',$fontSize);
    $pdf->SetXY($x,$y);
    $pdf->Cell($cardWidth,$cardHeight,$user,1,0,'C');

    $counter++;
}

// =========================
// حفظ PDF
// =========================
if(!is_dir("pdfs")) mkdir("pdfs");
$timestamp = date('Ymd_His');
$pdfPath = "pdfs/cards_$timestamp.pdf";
$pdf->Output("F",$pdfPath);

file_put_contents($progressFile,"تم إنشاء PDF، جاري إضافة المستخدمين...");

// =========================
// الاتصال بالميكروتك
// =========================
$API=new RouterosAPI();
$API->timeout=3;
$API->attempts=1;

$batchSize = 30;

if($API->connect('213.6.209.159:8788','rami','amiami199')){
    $count=0;
    $total=count($users);

    foreach($users as $user){
        $API->write('/ip/hotspot/user/add', false);
        $API->write("=name=$user", false);
        $API->write("=profile=$profile", false);
        $API->write("=limit-uptime={$hours}h", false);
        $API->write("=limit-bytes-total=".($data*1024*1024), true);

        $count++;

        if($count % $batchSize == 0 || $count == $total){
            file_put_contents($progressFile, "تم إضافة $count من $total مستخدم");
        }

        usleep(20000);
    }

    // إعادة إرسال آخر 40 مستخدم (حل مشكلة آخر دفعة)
    $retryUsers = array_slice($users, -40);
    foreach($retryUsers as $user){
        $API->write('/ip/hotspot/user/add', false);
        $API->write("=name=$user", false);
        $API->write("=profile=$profile", false);
        $API->write("=limit-uptime={$hours}h", false);
        $API->write("=limit-bytes-total=".($data*1024*1024), true);
        usleep(30000);
    }

    $API->disconnect();
    file_put_contents($progressFile,"اكتملت الإضافة: $count مستخدم");
}

// =========================
// إنشاء ملف توثيق الطبعة
// =========================
$file = "data/added_cards_$timestamp.added";
file_put_contents($file, implode(PHP_EOL, $users));

// =========================
// تحديث ملف المستخدمين لآخر شهرين
// =========================
$now = time();
$twoMonths = 60 * 60 * 24 * 60;

// نقرأ القديم وننظف المستخدمين القدامى
$existingLines = file_exists($recentFile)
    ? file($recentFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES)
    : [];

$cleaned = [];
foreach($existingLines as $line){
    if(strpos($line, '|') !== false){
        list($u, $t) = explode('|', $line);
        if(($now - $t) < $twoMonths){
            $cleaned[] = $u . "|" . $t;
        }
    }
}

// إضافة المستخدمين الجدد
foreach($users as $user){
    $cleaned[] = $user . "|" . $now;
}

// حفظ الملف
file_put_contents($recentFile, implode(PHP_EOL, $cleaned) . PHP_EOL);

// =========================
// عرض رابط التحميل
// =========================
if(file_exists($pdfPath)){
    echo "
    <div style='max-width:400px;margin:50px auto;text-align:center;font-family:Arial,sans-serif;'>
        <h3>تم إنشاء الكروت وإضافة المستخدمين للميكروتك</h3>
        <p>الرجاء الانتظار… سيتم تحويلك إلى رابط التحميل بعد <span id='seconds'>10</span> ثانية</p>
        <div style='width:100%;background:#eee;border-radius:10px;overflow:hidden;height:25px;margin-top:20px;'>
            <div id='progressBar' style='width:0%;height:100%;background:#4CAF50;text-align:center;color:white;line-height:25px;'>0%</div>
        </div>
        <div id='downloadLink' style='display:none;margin-top:20px;'>
            <a href='$pdfPath' style='padding:10px 20px;background:#4CAF50;color:white;text-decoration:none;border-radius:5px;'>تحميل PDF</a>
        </div>
    </div>

    <script>
        var totalSeconds = 10;
        var seconds = totalSeconds;
        var countdown = document.getElementById('seconds');
        var progressBar = document.getElementById('progressBar');
        var downloadLink = document.getElementById('downloadLink');

        var interval = setInterval(function(){
            seconds--;
            countdown.textContent = seconds;
            var percent = Math.round(((totalSeconds - seconds) / totalSeconds) * 100);
            progressBar.style.width = percent + '%';
            progressBar.textContent = percent + '%';
            if(seconds <= 0){
                clearInterval(interval);
                progressBar.style.display = 'none';
                countdown.parentElement.style.display = 'none';
                downloadLink.style.display = 'block';
            }
        }, 1000);
    </script>
    ";
} else {
    echo "<h3>حدث خطأ، لم يتم إنشاء ملف PDF</h3>";
}

// =========================
// التحسين النهائي (الخلفية) بدون تعطيل HTML
// =========================
if (ob_get_level()) {
    ob_flush();
}
flush();

if (function_exists('fastcgi_finish_request')) {
    fastcgi_finish_request();
}

?>